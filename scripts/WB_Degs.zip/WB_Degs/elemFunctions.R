#Elementery Function : to be souced by stattest.R




Designer<-function(matrix,group1,group2){
  sample<-colnames(matrix)
  t<-length(sample)
  l<-length(group1)
  a<-matrix(rep(0,t*l),nrow=t)
  
  for (i in 1 : l){
    a[which(sample==group1[i]),i]<-1
    a[which(sample==group2[i]),i]<-1
  }
  return(a)
}

Contraster<-function(l){
  if(l<3)
    stop("select at least 3 replicate per group")
  if(l<=26){
    lvls <-LETTERS[1:l]
    combinations<-combn(lvls,2)
    contrast<-paste(combinations[1,],combinations[2,],sep = "-")
    lis<-list(contrast=contrast,levels=lvls)
    return(lis)
  }
}

cl.data<-function(matrix,group1,group2){
  sample<-colnames(matrix)
  cl <- rep(0,length(sample))
  #cl[which(sample==group1)]<-0
  cl[which(sample==group2)]<-1
  return(cl)
}

cl.within<-function(matrix,group1,group2){
  sample<-colnames(matrix)
  l<-length(sample)
  cl <- rep(1,l)
  random<-sample(seq(l/2),floor(l/4))
  cl[random]<-0
  cl[(random+l/2)]<-0
  return(cl)
}

pvalWitCutOff<-function(vector){
  cutOff<-min(vector)
  return(round(cutOff,4))
}

fcWitCutOff<-function(vector){
  cutOff<-max(abs(vector))
  return(round(cutOff,2))
}

datagenelist<-function(list,group){
  reslist <- list()
  for( file in group){
    #data<-readLines(con = list$datapath[which(list$name==file)])
    data.raw<-scan(file = list$datapath[which(list$name==file)], what=character(),sep = "\t",skip = 1)
    data<-data.raw[seq(1,length(data.raw),3)]
    reslist[[sub("([^.]+)\\.[[:alnum:]]+$", "\\1",file)]]<-data
  }
  return(reslist)
}

venn.ploter <- function(list){
  
  
  l <- length(list)
  if ( l == 0)
    return ( grob() )
  if ( l == 1 ){
    venn.plot <- draw.single.venn(
      area = length(list[[1]]),
      category = names(list[1]),
      lwd = 5,
      lty = "blank",
      cex = 3,
      label.col = "orange",
      cat.cex = 2,
      cat.pos = 180,
      cat.dist = -0.30,
      cat.col = "black",
      fill = "red",
      alpha = 0.15
    )
    return(venn.plot)
  }
  if( l== 2 ){
    n1<-length(list[[1]])
    n2<-length(list[[2]])
    n12<-length(intersect(list[[1]],list[[2]]))
    venn.plot <- draw.pairwise.venn(
      area1 = n1,
      area2 = n2,
      cross.area = n12,
      category = c(names(list[1]), names(list[2])),
      fill = c("blue", "red"),
      lty = "blank",
      cex = 2,
      cat.cex = 2,
      cat.col = c("blue", "red"),
      cat.pos = c(285, 105),
      cat.dist = 0.09,
      cat.just = list(c(-1, -1), c(1, 1)),
      ext.pos = 30,
      ext.dist = -0.05,
      ext.length = 0.85,
      ext.line.lwd = 2,
      ext.line.lty = "dashed"
    )
    return(venn.plot)  
  }
  if( l== 3 ){
    n1<-length(list[[1]])
    n2<-length(list[[2]])
    n3<-length(list[[3]])
    n12<-length(intersect(list[[1]],list[[2]]))
    n13<-length(intersect(list[[1]],list[[3]]))
    n23<-length(intersect(list[[2]],list[[3]]))
    n123<-length(intersect(intersect(list[[1]],list[[2]]),list[[3]]))
    venn.plot <- draw.triple.venn(
      area1 = n1,
      area2 = n2,
      area3 = n3,
      n12 = n12,
      n23 = n23,
      n13 = n13,
      n123 = n123,
      category = c(names(list[1]), names(list[2]), names(list[3])),
      fill = c("blue", "red", "green"),
      lty = "blank",
      cex = 2,
      cat.cex = 2,
      cat.col = c("blue", "red", "green")
    )
    return(venn.plot)
  }
  if( l== 4 ){
    n1<-length(list[[1]])
    n2<-length(list[[2]])
    n3<-length(list[[3]])
    n4<-length(list[[4]])
    n12<-length(intersect(list[[1]],list[[2]]))
    n13<-length(intersect(list[[1]],list[[3]]))
    n14<-length(intersect(list[[1]],list[[4]]))
    n23<-length(intersect(list[[2]],list[[3]]))
    n24<-length(intersect(list[[2]],list[[4]]))
    n34<-length(intersect(list[[3]],list[[4]]))
    n123<-length(intersect(intersect(list[[1]],list[[2]]),list[[3]]))
    n124<-length(intersect(intersect(list[[1]],list[[2]]),list[[4]]))
    n134<-length(intersect(intersect(list[[1]],list[[3]]),list[[4]]))
    n234<-length(intersect(intersect(list[[2]],list[[3]]),list[[4]]))
    n1234<-length(intersect(intersect(intersect(list[[1]],list[[2]]),list[[3]]),list[[4]]))
    venn.plot <- draw.quad.venn(
      area1 = n1,
      area2 = n2,
      area3 = n3,
      area4 = n4,
      n12 = n12,
      n13 = n13,
      n14 = n14,
      n23 = n23,
      n24 = n24,
      n34 = n34,
      n123 = n123,
      n124 = n124,
      n134 = n134,
      n234 = n234,
      n1234 = n1234,
      category = c(names(list[1]), names(list[2]), names(list[3]),names(list[4])),
      fill = c("orange", "red", "green", "blue"),
      lty = "dashed",
      cex = 2,
      cat.cex = 2,
      cat.col = c("orange", "red", "green", "blue")
    )
    return(venn.plot)
  }
  if( l== 5 ){
    n1<-length(list[[1]])
    n2<-length(list[[2]])
    n3<-length(list[[3]])
    n4<-length(list[[4]])
    n5<-length(list[[5]])
    n12<-length(intersect(list[[1]],list[[2]]))
    n13<-length(intersect(list[[1]],list[[3]]))
    n14<-length(intersect(list[[1]],list[[4]]))
    n15<-length(intersect(list[[1]],list[[5]]))
    n23<-length(intersect(list[[2]],list[[3]]))
    n24<-length(intersect(list[[2]],list[[4]]))
    n25<-length(intersect(list[[2]],list[[5]]))
    n34<-length(intersect(list[[3]],list[[4]]))
    n35<-length(intersect(list[[3]],list[[5]]))
    n45<-length(intersect(list[[4]],list[[5]]))
    n123<-length(intersect(intersect(list[[1]],list[[2]]),list[[3]]))
    n124<-length(intersect(intersect(list[[1]],list[[2]]),list[[4]]))
    n125<-length(intersect(intersect(list[[1]],list[[2]]),list[[5]]))
    n134<-length(intersect(intersect(list[[1]],list[[3]]),list[[4]]))
    n135<-length(intersect(intersect(list[[1]],list[[3]]),list[[5]]))
    n145<-length(intersect(intersect(list[[1]],list[[4]]),list[[5]]))
    n234<-length(intersect(intersect(list[[2]],list[[3]]),list[[4]]))
    n235<-length(intersect(intersect(list[[2]],list[[3]]),list[[5]]))
    n245<-length(intersect(intersect(list[[2]],list[[4]]),list[[5]]))
    n345<-length(intersect(intersect(list[[3]],list[[4]]),list[[5]]))
    n1234<-length(intersect(intersect(intersect(list[[1]],list[[2]]),list[[3]]),list[[4]]))
    n1235<-length(intersect(intersect(intersect(list[[1]],list[[2]]),list[[3]]),list[[5]]))
    n1245<-length(intersect(intersect(intersect(list[[1]],list[[2]]),list[[4]]),list[[5]]))
    n1345<-length(intersect(intersect(intersect(list[[1]],list[[3]]),list[[4]]),list[[5]]))
    n2345<-length(intersect(intersect(intersect(list[[2]],list[[3]]),list[[4]]),list[[5]]))
    n12345<-length(intersect(intersect(intersect(intersect(list[[1]],list[[2]]),list[[3]]),list[[4]]),list[[5]]))
    venn.plot <- draw.quintuple.venn(
      area1 = n1,
      area2 = n2,
      area3 = n3,
      area4 = n4,
      area5 = n5,
      n12 = n12,
      n13 = n13,
      n14 = n14,
      n15 = n15,
      n23 = n23,
      n24 = n24,
      n25 = n25,
      n34 = n34,
      n35 = n35,
      n45 = n45,
      n123 = n123,
      n124 = n124,
      n125 = n125,
      n134 = n134,
      n135 = n135,
      n145 = n145,
      n234 = n234,
      n235 = n235,
      n245 = n245,
      n345 = n345,
      n1234 = n1234,
      n1235 = n1235,
      n1245 = n1245,
      n1345 = n1345,
      n2345 = n2345,
      n12345 = n12345,
      category = c(names(list[1]), names(list[2]), names(list[3]),names(list[4]),names(list[5])),
      fill = c("dodgerblue", "goldenrod1", "darkorange1", "seagreen3", "orchid3"),
      cat.col = c("dodgerblue", "goldenrod1", "darkorange1", "seagreen3", "orchid3"),
      cat.cex = 2,
      margin = 0.05,
      cex = c(1.5, 1.5, 1.5, 1.5, 1.5, 1, 0.8, 1, 0.8, 1, 0.8, 1, 0.8, 1, 0.8, 
              1, 0.55, 1, 0.55, 1, 0.55, 1, 0.55, 1, 0.55, 1, 1, 1, 1, 1, 1.5),
      ind = TRUE
    )
    return(venn.plot)
  }
  else
    return ( grob() )
}

vennIntersect<-function(list){
  l <- length(list)
  if ( l == 0)
    return ( "" )
  if ( l == 1 ){
    genInter <- list[[1]]
    return(genInter)
  }
  if( l== 2 ){
    genInter<-intersect(list[[1]],list[[2]])
    return(genInter)  
  }
  if( l== 3 ){
    genInter<-intersect(intersect(list[[1]],list[[2]]),list[[3]])
    return(genInter)
  }
  if( l== 4 ){
    genInter<-intersect(intersect(intersect(list[[1]],list[[2]]),list[[3]]),list[[4]])
    return(genInter)
  }
  if( l== 5 ){
    genInter<-intersect(intersect(intersect(intersect(list[[1]],list[[2]]),list[[3]]),list[[4]]),list[[5]])
    return(genInter)
  }
  else
    return ( "" )
}