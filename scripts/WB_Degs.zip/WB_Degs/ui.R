shinyUI(fluidPage(
  titlePanel("Within-Between Differential Expression Genes"),
  
  sidebarLayout(
    sidebarPanel(
      
      h3("1. Data Upload"),
      
      helpText("Please choose at least 3 replicates per experience."),
                       
      fileInput('files', 'Select CEL files to upload',
                multiple = TRUE,
                accept = c(
                  'text/csv',
                  '.CEL')),
      
      h3("2. PreProcessing"),
      
      conditionalPanel(
        condition = "output.fileUploaded",
        
        helpText("Please costumize your preprocessing method"),
        
        selectInput("bg_corr", "Background Correction Method :", 
                    choices = c("Choose a Method","RMA", "MAS")),
        
        selectInput("norm", "Normalization Method :", 
                    choices = c("Choose a Method","Quantiles", "Constant", "Loess","Qspline" ))
        
        
        ),
      
      h3("3. Gene Selection"),
      
      conditionalPanel(
        condition = "output.mat_cond",
        
        checkboxInput('genFiltering', 'Filter Genes', FALSE),
        helpText("filter out genes with a small variance across samples."),
        
        uiOutput("ui1"),
        uiOutput("ui2"),
        
        
        selectInput("select", "Statistical Analysis :", 
                    choices = c("Choose a Method",
                                "Simple Statistical Test",
                                "Twilight",
                                "Linear Models",
                                "Significance Analysis of Microarray")),
        
        helpText("Plots will update live to reflect changes."),
        
        uiOutput("ui3"),
        uiOutput("ui4")
        
      ),
      conditionalPanel(
        condition = "$('html').hasClass('shiny-busy')",
        
        img(src="small_loader.gif"))
      
      ),
    
    mainPanel(
      
      tabsetPanel(id="maintabset", selected="Gene Expression Matrix",
                  
                  tabPanel("Gene Expression Matrix",
                           conditionalPanel(
                             condition = "!output.mat_cond", 
                             tags$p("A Gene Expression Matrix Preview will be shown here when a valid inputs has been uploaded.")
                           ), 
                           conditionalPanel(
                             condition = "output.mat_cond",
                             
                             tags$p("Matrix Preview"),
                             tableOutput("GEMatrix"),
                             hr(),
                             tags$p("Download Full Matrix as text file"),
                             textInput("matGE_filename", label = "File Name :", value = "MatrixGE"),
                             downloadButton('dlmatrix', 'Download')
                           )
                           
                  ),
                  
                  tabPanel("Gene Selection Plots",
                           conditionalPanel(
                             condition = "!output.stat_method", 
                             tags$p("Plots will be shown here when a stastical method has been selected")
                           ), 
                           conditionalPanel(
                             condition = "output.stat_method",
                             div(class='row-fluid',
                             div(class="span6",plotOutput("res.plot")),
                             div(class="span6",plotOutput("volcano.wit"))
                             ),
                             hr(),
                             textOutput("genes_length"),
                             textOutput("genes_wit_length"),
                             hr(),
                             tags$p("Get expressed genes in text file"),
                             textInput("expGene_filename", label = "File Name :", value = "expr_genes"),
                             downloadButton('dlexpGene', 'Download'),
                             hr(),
                             tags$p("expressed Genes"),
                             verbatimTextOutput("value5"),
                             verbatimTextOutput("value7")
                            
                           )
                  ),
                  
                  tabPanel("Venn Diagram",
                           fileInput('selecgenefile', 'Choose files containing selected genes',
                                     multiple = TRUE,
                                     accept = c(
                                       'text/csv',
                                       '.txt')
                           ),
                           uiOutput("uitests"),
                           plotOutput("venn.plot",width = "550px", height = "500px"),
                           tags$p("Intersection :"),
                           verbatimTextOutput("value6")
                  )
                  
      )
      
    )
  )
))