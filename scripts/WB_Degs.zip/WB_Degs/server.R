# server.R
library("shiny")
library("affy")
library("affyPLM")
library("VennDiagram")
source("stattests.R")

options(shiny.maxRequestSize = 50*1024^2)


shinyServer(function(input, output,session) {
  
  sampleNames <- reactive({ 
    
    if(!is.null(input$files)) 
      return(unlist(input$files$name))
    else return(NULL)
     
  })
  
  inputdata <- reactive({ 
    if(!is.null(input$files)) {
      return(ReadAffy(filenames=unlist(input$files$datapath),
                      sampleNames=sampleNames()))
    }
    else return(NULL)
  })
  
  
  bgCorrMethod <- reactive({
    switch(input$bg_corr,
           "Choose a Method" = NULL,
           "RMA" = "rma",
           "MAS" = "mas")
  })
  
  normMethod <- reactive({
    switch(input$norm,
           "Choose a Method" = NULL,
           "Quantiles" = "quantiles",
           "Constant" = "constant",
           "Loess" = "loess",
           "Qspline" = "qspline")
  })
  
  selMethod <- reactive({
    switch(input$select,
           "Choose a Method" = NULL,
           "Simple Statistical Test" = "ttest",
           "Twilight" = "twilight",
           "Linear Models" = "lim",
           "Significance Analysis of Microarray" = "sam")
  })
  
  
  output$fileUploaded <- reactive({return(!is.null(input$files))})
  
  
  
  data.eset <- reactive({
    if (!is.null(bgCorrMethod()) && !is.null(normMethod()) ) {
      return(expresso(inputdata(),
               bgcorrect.method=bgCorrMethod(),
               normalize.method=normMethod(),
               pmcorrect.method="pmonly",
               summary.method="medianpolish"
               ))
    }
    else return (NULL)
  })
  
  #data.eset <- reactive({
  #  if (!is.null(bgCorrMethod()) && !is.null(normMethod()) ) {
  #    return(threestep(inputdata(),
  #                     background.method=bgCorrMethod(),
  #                     normalize.method=normMethod(),
  #                     #pmcorrect.method="pmonly",
  #                     summary.method="median.polish"
  #    ))
  #  }
  #  else return (NULL)
  #})
  
  eset <- reactive({
    if (!is.null(data.eset())){
      
      if(input$genFiltering){
        library(genefilter)
        return(varFilter(data.eset()))
      }
      else
        return(data.eset())
    }
    else return (NULL)
  })
  
  MatGE <- reactive({
    if (!is.null(eset())) {
      return(exprs(eset()))
    }
    else return (NULL)
  })
  
  output$mat_cond <- reactive({return(!is.null(MatGE()))})
  
  output$ui1 <- renderUI({ selectizeInput(
     'group1', 'Select Group 1 entries', choices = sampleNames(), multiple = TRUE
  )})
  
  output$ui2 <- renderUI({
    selectizeInput(
      'group2', 'Select Group 2 entries', choices = sampleNames(), multiple = TRUE
    )
  })
  
  output$ui3 <- renderUI({
    if (is.null(selMethod()))
      return()
    switch(selMethod(),
           "sam"= textInput("delta_cutt", label = "Delta Value", value = "2"),
           "ttest"= textInput("fc_cutt", label = "FC CuttOf", value = as.character(fcWitCutOff(test_result()[,4]))),
           "lim"= textInput("fc_cutt", label = "FC CuttOf", value = as.character(fcWitCutOff(test_result()[,4]))),
           "twilight"= textInput("fc_cutt", label = "FC CuttOf", value = as.character(fcWitCutOff(test_result()[,4])))
    )
  })
  
  output$ui4 <- renderUI({
    if (is.null(selMethod()) || selMethod()=="sam")
      return()
    switch(selMethod(),
           
           "ttest"= textInput("pv_cutt", label = "PValue CuttOf", value = as.character(pvalWitCutOff(test_result()[,3]))),
           "lim"= textInput("pv_cutt", label = "PValue CuttOf", value = as.character(pvalWitCutOff(test_result()[,3]))),
           "twilight"= textInput("pv_cutt", label = "PValue CuttOf", value = as.character(pvalWitCutOff(test_result()[,3])))
    )
  
  })
  
  test_result <- reactive({
    if (is.null(selMethod()))
      return(NULL)
    switch(selMethod(),
           "ttest"= ttest.betwit(MatGE(),input$group1,input$group2),
           "twilight"= twilight.test(MatGE(),input$group1,input$group2),
           "lim"= bet.wit.test(MatGE(),input$group1,input$group2),
           "sam"= sam.test(MatGE(),input$group1,input$group2))
    
  })
  
  test_result_wit <- reactive({
    if (is.null(selMethod()))
      return(NULL)
    if(selMethod()=="sam")
       return(sam.test.wit(MatGE(),input$group1,input$group2))
    else
      return(NULL)  
  })
  
  output$stat_method <- reactive({return(!is.null(selMethod()))})
  
  output$res.plot <- renderPlot({
    
    if (!is.null(test_result()) & (selMethod()=="lim"||selMethod()=="ttest"||selMethod()=="twilight")
        & !is.null(input$fc_cutt) & !is.null(input$pv_cutt)){
      
      pvc <- -log10(as.numeric(input$pv_cutt))
      fcc <- as.numeric(input$fc_cutt)
      xlimit<-ifelse(max(abs(test_result()[,2])) < 15 , max(abs(test_result()[,2])) ,15 )
      ylimit<-ifelse(max(-log10(test_result()[,1])) < 12 , max(-log10(test_result()[,1])) ,12 )
      
      plot(test_result()[,2], -log10(test_result()[,1]),xlab="SLR",ylab="Significativity",
           xlim=c(-xlimit,xlimit),ylim=c(0,ylimit),
           col=ifelse((abs(test_result()[,2])>fcc &
                          -log10(test_result()[,1])>pvc),"red","black"),
           xaxt="n",main="Between Group Comparaison")
      axis(1, -ceiling(xlimit):ceiling(xlimit))
      
      abline(v=fcc,lty=2)
      abline(v=-fcc,lty=2)
      abline(h=pvc,lty=2)
    }
    else if (!is.null(test_result()) & selMethod()=="sam" & !is.null(input$delta_cutt)){
      dc <- as.numeric(input$delta_cutt)
      plot(test_result(),dc)
    }
  })
  
  output$volcano.wit <- renderPlot({
    
    if (!is.null(test_result()) & (selMethod()=="lim"||selMethod()=="ttest"||selMethod()=="twilight"))
      {
      pvc <- -log10(as.numeric(input$pv_cutt))
      fcc <- as.numeric(input$fc_cutt)
      xlimit<-ifelse(max(abs(test_result()[,2])) < 15 , max(abs(test_result()[,2])) ,15 )
      ylimit<-ifelse(max(-log10(test_result()[,1])) < 12 , max(-log10(test_result()[,1])) ,12 )
      
      plot(test_result()[,4], -log10(test_result()[,3]),xlab="SLR",ylab="Significativity",
           xlim=c(-xlimit,xlimit),ylim=c(0,ylimit),
           col=ifelse((abs(test_result()[,4])>fcc &
                         -log10(test_result()[,3])>pvc),"red","black"),
           xaxt="n",main="Within Group Comparaison")
      axis(1, -ceiling(xlimit):ceiling(xlimit))
      
      abline(v=fcc,lty=2)
      abline(v=-fcc,lty=2)
      abline(h=pvc,lty=2)
    }
    else if (!is.null(test_result()) & selMethod()=="sam" & !is.null(input$delta_cutt)){
      dc <- as.numeric(input$delta_cutt)
      plot(test_result_wit(),dc)
    }
  })
  
  exprGene_list <- reactive({
    if (is.null(test_result()))
      return(NULL)
    switch(selMethod(),
           "ttest"= wb_genes(test_result(),as.numeric(input$pv_cutt),as.numeric(input$fc_cutt)),
           "twilight"= wb_genes(test_result(),as.numeric(input$pv_cutt),as.numeric(input$fc_cutt)),
           "lim"= wb_genes(test_result(),as.numeric(input$pv_cutt),as.numeric(input$fc_cutt)),
           "sam"= sam_genes(MatGE(),test_result(),as.numeric(input$delta_cutt)))
    
  })
  
  exprGene_wit_list <- reactive({
    if (is.null(test_result()))
      return(NULL)
    switch(selMethod(),
           "ttest"= wb_genes_wit(test_result(),as.numeric(input$pv_cutt),as.numeric(input$fc_cutt)),
           "twilight"= wb_genes_wit(test_result(),as.numeric(input$pv_cutt),as.numeric(input$fc_cutt)),
           "lim"= wb_genes_wit(test_result(),as.numeric(input$pv_cutt),as.numeric(input$fc_cutt)),
           "sam"= sam_genes(MatGE(),test_result_wit(),as.numeric(input$delta_cutt)))
           
    
  })
  
  ###venndiagram ui
  
  inputtest <- reactive({ 
    if(!is.null(input$selecgenefile)) {
      return(input$selecgenefile)
    } else return(NULL)
  })
  
  output$uitests <- renderUI({
    selectizeInput(
      'group', 'select files to compare', choices = inputtest()$name, multiple = TRUE
    )
  })
  
  genesData <- reactive({
    if(!is.null(input$group)){
      datalist<-datagenelist(inputtest(),input$group)
      return (datalist)
    }
    else
      return (NULL)
  })
  
  output$venn.plot <- renderPlot({
    if (!is.null(genesData())){
      grid.draw(venn.ploter(genesData())) 
    }
  })
  
  genesIntersect <- reactive({
    if (!is.null(genesData())){
      inters<-vennIntersect(genesData())
      return (inters)
    }
    else
      return (NULL)
  })
  
  ###
    
  output$dlmatrix <- downloadHandler(

    filename = function() {
      paste(input$matGE_filename, '.txt', sep="")
    },
    content = function(file) {
      write.table(MatGE(), file, sep = ",",col.names = NA)
    }
  )
  
  output$dlexpGene<- downloadHandler(
    
    filename = function() {
      paste(input$expGene_filename, '.txt', sep="")
    },
    content = function(file) {
      #cat(exprGene_list() , file = file, sep = "\n", fill = FALSE, labels = NULL,
      #    append = FALSE)
      write.table(exprGene_list(), file = file, sep = '\t', col.names = NA)
    }
  )
    
  output$genes_length <- renderText({ paste("genes selected between expriences : ",nrow(exprGene_list()))})
  
  output$genes_wit_length <- renderText({ paste("genes selected within expriences : ",nrow(exprGene_wit_list()))})

  output$value5 <- renderPrint({ exprGene_list() })
  output$value6 <- renderPrint({ genesIntersect() })
  output$value7 <- renderPrint({ exprGene_wit_list() })
  
  output$GEMatrix <- renderTable({ MatGE()[1:30,] })
  
  outputOptions(output, "fileUploaded", suspendWhenHidden = FALSE)
  outputOptions(output, "mat_cond", suspendWhenHidden = FALSE)
  outputOptions(output, "stat_method", suspendWhenHidden = FALSE)
  
  
  observe({
    
    if(is.null(input$files)){
      
      updateSelectInput(session,"bg_corr",
                        selected = "Choose a Method")
      
      updateSelectInput(session,"norm",
                        selected = "Choose a Method")
      
      updateSelectInput(session,"select",
                        selected = "Choose a Method")
    }
  })

  
}
)