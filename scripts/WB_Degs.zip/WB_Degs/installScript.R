#installing Packages

# 1 - Cran

install.packages("shiny")
install.packages("VennDiagram")


# 2- Bioconductor

source("http://bioconductor.org/biocLite.R")
biocLite("affy")
biocLite("affyPLM")
biocLite("limma")
biocLite("siggenes")
biocLite("twilight")
biocLite("genefilter")
