#Statestic Tests : contain code for all the statistical methods used in WB-DEGS


source(file = "elemFunctions.R")

fcrosTtest<-function (xdata, cont, test, log2.opt = 1) 
{
  n <- nrow(xdata)
  idnames <- xdata[, 1]
  xcol <- colnames(xdata)
  n.xcol <- length(xcol)
  idx1 <- xcol %in% cont
  m1 <- sum(idx1 == TRUE)
  idx2 <- xcol %in% test
  m2 <- sum(idx2 == TRUE)
  m <- m1 + m2
  dmat <- matrix(c(rep(0, n * m)), ncol = m)
  if (log2.opt) {
    x1 <- log2(xdata[, idx1 == TRUE])
  }
  else {
    x1 <- xdata[, idx1 == TRUE]
  }
  dmat[, 1:m1] <- as.matrix(x1)
  if (log2.opt) {
    x2 <- log2(xdata[, idx2 == TRUE])
  }
  else {
    x2 <- xdata[, idx2 == TRUE]
  }
  dmat[, (m1 + 1):m] <- as.matrix(x2)
  FC <- matrix(c(rep(0, n)), ncol = 1)
  p.value <- matrix(c(rep(0, n)), ncol = 1)
  stat <- matrix(c(rep(0, n)), ncol = 1)
  for (i in 1:n) {
    x1 <- dmat[i, 1:m1]
    x2 <- dmat[i, (m1 + 1):m]
    if ((sd(x1) + sd(x2)) == 0) {
      p.value[i] <- 1
      stat[i] <- 0
    }
    else {
      tt <- t.test(x1, x2, var.equal = TRUE)
      p.value[i] <- tt$p.value
      stat[i] <- tt$statistic
    }
    FC[i] <- mean(2^x2)/mean(2^x1)
  }
  list(idnames = idnames, FC = FC, p.value = p.value, stat = stat)
}

ttest.betwit<-function(matrixge,group1,group2){
  
  name<- rownames(matrixge)
  
  #between groups
  
  fcttest<-fcrosTtest(xdata=matrixge, cont=group1, test=group2, log2.opt = 1)
  
  pval.bet<- fcttest$p.value
  
  fc.bet<-log2(fcttest$FC)

  
  #within
  
  n <- length(group1)
  m <- ceiling(n/2)

  if ( (n %% 2) == 0) {
    cont1 <- sample(group1,m)
    test1 <- sample(group1,m)
    while (length(intersect(cont1,test1))!=0)
      test1 <- sample(group1,m)
    
    cont2 <- sample(group2,m)
    test2 <- sample(group2,m)
    while (length(intersect(cont2,test2))!=0)
      test2 <- sample(group2,m)
    }
  
  else {
    cont1 <- sample(group1,m)
    test1 <- sample(group1,m)
    while (length(intersect(cont1,test1))!=1)
      test1 <- sample(group1,m)
    
    cont2 <- sample(group2,m)
    test2 <- sample(group2,m)
    while (length(intersect(cont2,test2))!=1)
      test2 <- sample(group2,m)
  }
  
  
  fcttest1<-fcrosTtest(xdata=matrixge, cont=cont1, test=test1, log2.opt = 1)
  pval1<- fcttest1$p.value
  fcc1<-log2(fcttest1$FC)
  
  
  fcttest2<-fcrosTtest(xdata=matrixge, cont=cont2, test=test2, log2.opt = 1)
  pval2<- fcttest2$p.value
  fcc2<-log2(fcttest2$FC)
  
  fc.wit<-(fcc1+fcc2)/2
  
  pval.wit<-(pval1+pval2)/2
  
  result <- cbind(pval.bet,fc.bet,pval.wit,fc.wit)
  rownames(result)<- name
  colnames(result)<-c("b.pValue","b.foldChange","w.pValue","w.foldChange")
  
  return(result)
  
}


bet.wit.test<-function(matrix,group1,group2){
library(limma)

name<- rownames(matrix)

sample<-colnames(matrix)
A <- B <- rep(0,length(sample))
A[which(sample==group1)]<-1
B[which(sample==group2)]<-1

design <- cbind(A,B)
fit <- lmFit(matrix,design)
contrast.matrix <- makeContrasts(A-B,levels=design)				
model.contrast <- contrasts.fit(fit,contrast.matrix)				
statistics <- eBayes(model.contrast)				
pval<-statistics$p.value
rownames(pval)<- name
FC <- statistics$coefficients
rownames(FC)<- name
resu.bet<-cbind(pval,FC)

colnames(resu.bet)<-c("b.pValue","b.foldChange")


design <- Designer(matrix,group1,group2)
fit <- lmFit(matrix,design)
constr<-Contraster(length(group1))
contrast.matrix <- makeContrasts(contrasts = constr$contrast,levels=constr$levels)				
model.contrast <- contrasts.fit(fit,contrast.matrix)
statistics <- eBayes(model.contrast)				
pval<-rowMeans(statistics$p.value)
FC<- rowMeans(statistics$coefficients)
resu.wit<-cbind(pval,FC)
colnames(resu.wit)<-c("w.pValue","w.foldChange")

result <- cbind(resu.bet,resu.wit)

return(result)
}


sam.test <- function(matrix,group1,group2) {
  
  library(siggenes)
  
  cl<-cl.data(matrix,group1,group2)
  sam.out <- sam(matrix, cl, B=100, rand=123)
  
  return(sam.out)
}

sam.test.wit <- function(matrix,group1,group2) {
  
  library(siggenes)
  
  cl<-cl.within(matrix,group1,group2)
  sam.out <- sam(matrix, cl, B=100, rand=123)
  
  return(sam.out)
}

twilight.test<-function(matrix,group1,group2){
  library(twilight)
  cl<-cl.data(matrix,group1,group2)
  #bet
  
  tw<-twilight.pval(matrix,cl)
  pvalu.tw<-tw$result$pvalue
  FC.tw<-NULL
  names(pvalu.tw)<-rownames(matrix)[tw$result$index]
  for (i in names(pvalu.tw)) {
    FC.tw[i] <- log2(mean(2^matrix[i,group2])/mean(2^matrix[i,group1]))
  }
  
  
  #wit
  clwit<-cl.within(matrix,group1,group2)
  
  twwit<-twilight.pval(matrix,clwit)
  pvalu.twwit<-twwit$result$pvalue
  names(pvalu.twwit)<-rownames(matrix)[twwit$result$index]
  
  clInter<-clwit[1:length(group1)]
  gp21<-group2[which(clInter==1)]
  gp22<-group2[which(clInter==0)]
  gp11<-group1[which(clInter==1)]
  gp12<-group1[which(clInter==0)]
  
  FC.twwit<-NULL
  for (i in names(pvalu.twwit)) {
    FC.twwit[i] <- log2 (mean( (mean(2^matrix[i,gp11])/mean(2^matrix[i,gp12])),
                          (mean(2^matrix[i,gp21])/mean(2^matrix[i,gp22])) ) )
  }
  
  res<-cbind(pvalu.tw,FC.tw,pvalu.twwit,FC.twwit)
  return(res)
  
}

sam_genes<- function(matrix,sam.out,delta){
  gene.name <- rownames(matrix)
  sam.sum <- summary(sam.out, delta, entrez=FALSE)
  #expGene <- gene.name[sam.sum@row.sig.genes]
  expGene.pval <- sam.out@p.value[sam.sum@row.sig.genes]
  expGene.fc <- sam.out@fold[sam.sum@row.sig.genes]
  expGene<-cbind(expGene.pval,expGene.fc)
  rownames(expGene)<-gene.name[sam.sum@row.sig.genes]
  colnames(expGene)<-c("p-value","FC")
  expGene <-expGene[order(expGene[,1],decreasing = FALSE),]
  return(expGene)
}

wb_genes <- function(test.out,pvcut,fccut){
  #expGene <- NULL
  expGene <- data.frame(p_value = numeric(), FC = numeric(), stringsAsFactors = FALSE)
  gene.name <- rownames(test.out)
  for(i in gene.name){	
    if(test.out[i,1]<pvcut && abs(test.out[i,2])>fccut){
      #expGene <- c(expGene,i)
      expGene[i,] <- list(test.out[i,1],test.out[i,2])
    } 
  }
  expGene <-expGene[order(expGene[,1],decreasing = FALSE),]
  return (expGene)
}

wb_genes_wit <- function(test.out,pvcut,fccut){
  #expGene <- NULL
  expGene <- data.frame(p_value = numeric(), FC = numeric(), stringsAsFactors = FALSE)
  gene.name <- rownames(test.out)
  for(i in gene.name){  
    if(test.out[i,3]<pvcut && abs(test.out[i,4])>fccut){
      expGene[i,] <- list(test.out[i,3],test.out[i,4])
      #expGene <- c(expGene,i)
    }
  }
  expGene <-expGene[order(expGene[,1],decreasing = FALSE),]
  return (expGene)
}