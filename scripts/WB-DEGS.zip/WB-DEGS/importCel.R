################################################################################
# author : Lamiaa LAHLOU.													   #
# directed by: Ahmed MOUSSA                                                    #  
# Abdelmalek Essaadi University.											   #
# National School of Applied Sciences of Tangier.							   #
# Master Computer Science and Complex Systems.								   #
# August 2013.																   #
################################################################################
################################################################################
# DATA IMPORT 																   #
################################################################################
########     FUNCTION IMPORT DATA  Cel FileAFFYMETRIX    ########
		
	
				########The user selected chips########
	importCel<-function()
		{
	library(affy)
	library("tkWidgets")
	filenames<<-list.celfiles()

		data.raw<<- ReadAffy(widget=TRUE)

		tkmessageBox(title="Fin",message="Successfull Importation", icon="info", type="ok")
		}