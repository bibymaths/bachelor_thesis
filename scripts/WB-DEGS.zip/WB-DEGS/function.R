##########################
##Source Function#########

#load data
source("C:/WB-DEGS/importCel.R")


#preprocessing
source("C:/WB-DEGS/preprocessing.R")


#Test Multiple
source("C:/WB-DEGS/selection.R")


