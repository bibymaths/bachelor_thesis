################################################################################
# author : Lamiaa LAHLOU.													   #
# directed by: Ahmed MOUSSA                                                    #  
# Abdelmalek Essaadi University.											   #
# National School of Applied Sciences of Tangier.							   #
# Master Computer Science and Complex Systems.								   #
# August 2013.																   #
################################################################################
################################################################################
# Main																		   #
################################################################################
require(tcltk)
################################
rm(list=ls(all=TRUE)) 
source("C:/WB-DEGS/function.R")
###################################
tt <- tktoplevel(background="white")
#tkwm.geometry(tt, "500x400")
tkwm.title(tt,"WB-FDR")

topMenu <- tkmenu(tt)
tkconfigure(tt,menu=topMenu)
openRecentMenu=tkmenu(topMenu,tearoff=FALSE)

#Data
DataMenu <- tkmenu(topMenu,tearoff=FALSE)
tkadd(DataMenu,"command",label="Step1: Import Raw Data",command=importCel)

	# Preprocessing
PreproMenu <- tkmenu(topMenu,tearoff=FALSE)
tkadd(PreproMenu,"command",label=" Correction Background , Normalization and summurization",command=prepro)

# Relative analysis 
analysrelaMenu <- tkmenu(topMenu,tearoff=FALSE)
tkadd(analysrelaMenu,"command",label="BW-DEGS",command=selecc)

# Add in all the sub menus

tkadd(topMenu,"cascade",label="Import",menu=DataMenu)
tkadd(topMenu,"cascade",label="Preprocessing",menu=PreproMenu)
tkadd(topMenu,"cascade",label="BW-DEGS",menu=analysrelaMenu)

####
fontHeading <- tkfont.create(family="times",size=24,weight="bold")
Label.title=tklabel(tt,text=" WB-DEGS Gene Selection",background="white",font=fontHeading);

 
tkgrid(Label.title)

tkfocus(tt);

