################################################################################
# author : Lamiaa LAHLOU.													   #
# directed by: Ahmed MOUSSA                                                    #  
# Abdelmalek Essaadi University.											   #
# National School of Applied Sciences of Tangier.							   #
# Master Computer Science and Complex Systems.								   #
# August 2013.																   #
################################################################################
################################################################################
# Preprocessing 															   #
################################################################################
prepro<-function()
{
PreP<-function()
{
require(tcltk)
	tt.sub<-tktoplevel(tt)
	tkwm.title(tt.sub,"Preprocessing Microarray :")
	tkwm.deiconify(tt.sub)
	tkgrab.set(tt.sub)
	tkfocus(tt.sub)

	FrameMain.tt <- tkframe(tt.sub)

	font.tmp<- tkfont.create(family="times",size=12,weight="bold",slant="italic");

	frame0 <- tkframe(FrameMain.tt,relief="flat",borderwidth=2)
	frame1 <- tkframe(FrameMain.tt,relief="flat",borderwidth=2)
	frame1a <- tkframe(frame1,relief="groove",borderwidth=5)
	frame1b <- tkframe(frame1,relief="groove",borderwidth=5)
	frame1.1 <- tkframe(frame1a ,relief="flat",borderwidth=2)
			frame1.1.1 <- tkframe(frame1.1,relief="flat",borderwidth=2)
			frame1.1.2 <- tkframe(frame1.1,relief="flat",borderwidth=2)
	frame1.2 <- tkframe(frame1b ,relief="flat",borderwidth=2)
			frame1.2.1 <- tkframe(frame1.2,relief="flat",borderwidth=2)
			frame1.2.2 <- tkframe(frame1.2,relief="flat",borderwidth=2)
	frame2 <- tkframe(FrameMain.tt,relief="flat",borderwidth=2)
frame1.3 <- tkframe(frame1b ,relief="flat",borderwidth=2)
			frame1.3.1 <- tkframe(frame1.3,relief="flat",borderwidth=2)
			frame1.3.2 <- tkframe(frame1.3,relief="flat",borderwidth=2)
frame1.4 <- tkframe(frame1b ,relief="groove",borderwidth=2)
			frame1.4.1 <- tkframe(frame1.4,relief="flat",borderwidth=2)
			frame1.4.2 <- tkframe(frame1.4,relief="flat",borderwidth=2)
	width1=60;
	width2=30;
	tkgrid(tklabel(frame0,text="Please customize your preprocessing method:",width=width1,font=font.tmp));

	list1=c("rma","mas","none");	
	list2=c("quantiles","constant","contrasts","invariantset","loess","qspline","quantiles.robust","scaling");
	list3=c("pmonly","mas","subtractmm");
	list4=c("medianpolish","avgdiff","liwong","mas","playerout","farms");
	list2.1=c("RMA(recommended)","MAS(From Affymetrix)","None");	
	list2.2=c("Quantiles(recommended)","Constant","Contrasts","Invariantset(Dchip)","Loess","Qspline","Quantiles.robust","Scaling");
	list2.3=c("Pmonly(recommended)","Mas","subtractmm");
	list2.4=c("medianpolish (recommended)","avgdiff","liwong","mas","playerout","FARMS");

	label1=tklabel(frame1.1.1,text="background correction method:",width=width2,font=font.tmp,anchor="w")
	label2=tklabel(frame1.2,text="normalization method:",width=width2,font=font.tmp,anchor="w")
	label3=tklabel(frame1.3,text="pm correction method:",width=width2,font=font.tmp,anchor="w")
	label4=tklabel(frame1.1.2,text="summary method:",width=width2,font=font.tmp,anchor="w")
######################### 1	
	tkgrid(label1);
	rbValue1 <- tclVar(list1[1])
	rbs1=list();
	for (i in 1:length(list1)) {
 		 rbs1[[i]]=tkradiobutton(frame1.1.2, text=list2.1[i], value=list1[i], variable=rbValue1)
 		 tkgrid(rbs1[[i]],sticky="w")
	}
######################### 2	
	tkgrid(label2);
	rbValue2 <- tclVar(list2[1])
	rbs2=list();
	for (i in 1:length(list2)) {
 		 rbs2[[i]]=tkradiobutton(frame1.2.2, text=list2.2[i], value=list2[i], variable=rbValue2)
 		 tkgrid(rbs2[[i]],sticky="w")
	}
######################### 3
	tkgrid(label3);
	rbValue3 <- tclVar(list3[1])
	rbs3=list();
	for (i in 1:length(list3)) {
 		 rbs3[[i]]=tkradiobutton(frame1.3.2, text=list2.3[i], value=list3[i], variable=rbValue3)
 		 tkgrid(rbs3[[i]],sticky="w")
	}
########################### 4
	tkgrid(label4);
	rbValue4 <- tclVar(list4[1])
	rbs4=list();
	for (i in 1:length(list4)) {
 		 rbs4[[i]]=tkradiobutton(frame1.1.2, text=list2.4[i], value=list4[i], variable=rbValue4)
 		 tkgrid(rbs4[[i]],sticky="w")
	}
###############################
	
      Choice1=tclVar(-1);
      Choice2=tclVar(-1);
      Choice3=tclVar(-1);
     	Choice4=tclVar(-1);
	OnOK <- function()
	{
	    tclvalue(Choice1) <- as.character(tclvalue(rbValue1));
	    tclvalue(Choice2) <- as.character(tclvalue(rbValue2));
	    tclvalue(Choice3) <- as.character(tclvalue(rbValue3));
	    tclvalue(Choice4) <- as.character(tclvalue(rbValue4));
	    tkdestroy(tt.sub)
	}
	OnCancel <- function()
	{
	    tkdestroy(tt.sub)
	}
	
	OK.but <-tkbutton(frame2,text="   OK   ",command=OnOK)
	Cancel.but <-tkbutton(frame2,text="   Cancel   ",command=OnCancel)
	tkgrid(OK.but,Cancel.but)
	
	

	tkgrid(frame0);
	tkgrid(frame1.1);tkgrid(frame1.1.1);tkgrid(frame1.1.2);
	tkgrid(frame1.2);tkgrid(frame1.2.1);tkgrid(frame1.2.2);
	tkgrid(frame1.3.1);tkgrid(frame1.3.2);
	tkgrid(frame1.3);
	tkgrid(tklabel(frame1a,text=" Save the Matrix Gene/Expression  ",height=3,width=width2));
	tkgrid(frame1.4.1);tkgrid(frame1.4.2);tkgrid(frame1.4);
	tkgrid(tklabel(frame1a,text="   ",height=1,width=width2));
	tkgrid(frame1a,frame1b,sticky="n");
	tkgrid(frame1);
	tkgrid(frame2);
	tkgrid(FrameMain.tt);
	tkfocus(tt.sub)
	tkwait.window(tt.sub)
	return(list(tclvalue(Choice1),tclvalue(Choice2),tclvalue(Choice3),tclvalue(Choice4)));
}
sel=PreP();


			if(sel[[1]]=="-1") {tkconfigure(tt,cursor="arrow");tkfocus(tt);return();}
			data.eset<<-expresso(data.raw, 
				 bgcorrect.method=sel[[1]],
	                   normalize.method=sel[[2]],
				 pmcorrect.method=sel[[3]],
	                   summary.method=sel[[4]],
				 widget = F	);
data.Norm.exp<<-exprs(data.eset)
				 fileName <- tclvalue(tkgetSaveFile())
	if (!nchar(fileName)) {
    	tkmessageBox(message = "No file was selected!")
	} else {
    	tkmessageBox(message = paste("The file selected was", fileName))
	}
	write.table(data.Norm.exp, file = fileName, sep = ",", col.names = NA)	
	
tkmessageBox(title="Fin",message="preprocessing complete",icon="info",type="ok")
}
