################################################################################
# author : Lamiaa LAHLOU.													   #
# directed by: Ahmed MOUSSA                                                    #  
# Abdelmalek Essaadi University.											   #
# National School of Applied Sciences of Tangier.							   #
# Master Computer Science and Complex Systems.								   #
# August 2013.																   #
################################################################################
################################################################################
# Install packages 															   #
################################################################################
install.packages("tkrplot")
install.packages("tcltk")
source("http://bioconductor.org/biocLite.R")
    biocLite("limma")
	biocLite("affy")

